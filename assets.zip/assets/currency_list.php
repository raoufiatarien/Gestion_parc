
<option value="AED,AED">&emsp;AED</option>
        
<option value="AFN,AFN">&emsp;AFN</option>

<option value="ALL,ALL">&emsp;ALL</option>

<option value="AMD,AMD">&emsp;AMD</option>

<option value="ANG,ANG">&emsp;ANG</option>

<option value="AOA,AOA">&emsp;AOA</option>

<option value="ARS,ARS">&emsp;ARS</option>

<option value="AUD,AUD">&emsp;AUD</option>

<option value="AWG,AWG">&emsp;AWG</option>

<option value="AZN,AZN">&emsp;AZN</option>

<option value="BAM,BAM">&emsp;BAM</option>

<option value="BBD,BBD">&emsp;BBD</option>

<option value="BDT,BDT">&emsp;BDT</option>

<option value="BGN,BGN">&emsp;BGN</option>

<option value="BHD,BHD">&emsp;BHD</option>

<option value="BIF,BIF">&emsp;BIF</option>

<option value="BMD,BMD">&emsp;BMD</option>

<option value="BND,BND">&emsp;BND</option>

<option value="BOB,BOB">&emsp;BOB</option>

<option value="BRL,BRL">&emsp;BRL</option>

<option value="BSD,BSD">&emsp;BSD</option>

<option value="BTC,BTC">&emsp;BTC</option>

<option value="BTN,BTN">&emsp;BTN</option>

<option value="BWP,BWP">&emsp;BWP</option>

<option value="BYN,BYN">&emsp;BYN</option>

<option value="BYR,BYR">&emsp;BYR</option>

<option value="BZD,BZD">&emsp;BZD</option>

<option value="CAD,CAD">&emsp;CAD</option>

<option value="CDF,CDF">&emsp;CDF</option>

<option value="CHF,CHF">&emsp;CHF</option>

<option value="CLF,CLF">&emsp;CLF</option>

<option value="CLP,CLP">&emsp;CLP</option>

<option value="CNY,CNY">&emsp;CNY</option>

<option value="COP,COP">&emsp;COP</option>

<option value="CRC,CRC">&emsp;CRC</option>

<option value="CUC,CUC">&emsp;CUC</option>

<option value="CUP,CUP">&emsp;CUP</option>

<option value="CVE,CVE">&emsp;CVE</option>

<option value="CZK,CZK">&emsp;CZK</option>

<option value="DJF,DJF">&emsp;DJF</option>

<option value="DKK,DKK">&emsp;DKK</option>

<option value="DOP,DOP">&emsp;DOP</option>

<option value="DZD,DZD">&emsp;DZD</option>

<option value="EGP,EGP">&emsp;EGP</option>

<option value="ERN,ERN">&emsp;ERN</option>

<option value="ETB,ETB">&emsp;ETB</option>

<option value="EUR,EUR">&emsp;EUR</option>

<option value="XAF,FCFA">&emsp;FCFA</option>

<option value="FJD,FJD">&emsp;FJD</option>

<option value="FKP,FKP">&emsp;FKP</option>

<option value="GBP,GBP">&emsp;GBP</option>

<option value="GEL,GEL">&emsp;GEL</option>

<option value="GGP,GGP">&emsp;GGP</option>

<option value="GHS,GHS">&emsp;GHS</option>

<option value="GIP,GIP">&emsp;GIP</option>

<option value="GMD,GMD">&emsp;GMD</option>

<option value="GNF,GNF">&emsp;GNF</option>

<option value="GTQ,GTQ">&emsp;GTQ</option>

<option value="GYD,GYD">&emsp;GYD</option>

<option value="HKD,HKD">&emsp;HKD</option>

<option value="HNL,HNL">&emsp;HNL</option>

<option value="HRK,HRK">&emsp;HRK</option>

<option value="HTG,HTG">&emsp;HTG</option>

<option value="HUF,HUF">&emsp;HUF</option>

<option value="IDR,IDR">&emsp;IDR</option>

<option value="ILS,ILS">&emsp;ILS</option>

<option value="IMP,IMP">&emsp;IMP</option>

<option value="INR,INR">&emsp;INR</option>

<option value="IQD,IQD">&emsp;IQD</option>

<option value="IRR,IRR">&emsp;IRR</option>

<option value="ISK,ISK">&emsp;ISK</option>

<option value="JEP,JEP">&emsp;JEP</option>

<option value="JMD,JMD">&emsp;JMD</option>

<option value="JOD,JOD">&emsp;JOD</option>

<option value="JPY,JPY">&emsp;JPY</option>

<option value="KES,KES">&emsp;KES</option>

<option value="KGS,KGS">&emsp;KGS</option>

<option value="KHR,KHR">&emsp;KHR</option>

<option value="KMF,KMF">&emsp;KMF</option>

<option value="KPW,KPW">&emsp;KPW</option>

<option value="KRW,KRW">&emsp;KRW</option>

<option value="KWD,KWD">&emsp;KWD</option>

<option value="KYD,KYD">&emsp;KYD</option>

<option value="KZT,KZT">&emsp;KZT</option>

<option value="LAK,LAK">&emsp;LAK</option>

<option value="LBP,LBP">&emsp;LBP</option>

<option value="LKR,LKR">&emsp;LKR</option>

<option value="LRD,LRD">&emsp;LRD</option>

<option value="LSL,LSL">&emsp;LSL</option>

<option value="LVL,LVL">&emsp;LVL</option>

<option value="LYD,LYD">&emsp;LYD</option>

<option value="MAD,MAD">&emsp;MAD</option>

<option value="MDL,MDL">&emsp;MDL</option>

<option value="MGA,MGA">&emsp;MGA</option>

<option value="MKD,MKD">&emsp;MKD</option>

<option value="MMK,MMK">&emsp;MMK</option>

<option value="MNT,MNT">&emsp;MNT</option>

<option value="MOP,MOP">&emsp;MOP</option>

<option value="MRO,MRO">&emsp;MRO</option>

<option value="MUR,MUR">&emsp;MUR</option>

<option value="MVR,MVR">&emsp;MVR</option>

<option value="MWK,MWK">&emsp;MWK</option>

<option value="MXN,MXN">&emsp;MXN</option>

<option value="MYR,MYR">&emsp;MYR</option>

<option value="MZN,MZN">&emsp;MZN</option>

<option value="NAD,NAD">&emsp;NAD</option>

<option value="NGN,NGN">&emsp;NGN</option>

<option value="NIO,NIO">&emsp;NIO</option>

<option value="NOK,NOK">&emsp;NOK</option>

<option value="NPR,NPR">&emsp;NPR</option>

<option value="NZD,NZD">&emsp;NZD</option>

<option value="OMR,OMR">&emsp;OMR</option>

<option value="PAB,PAB">&emsp;PAB</option>

<option value="PEN,PEN">&emsp;PEN</option>

<option value="PGK,PGK">&emsp;PGK</option>

<option value="PHP,PHP">&emsp;PHP</option>

<option value="PKR,PKR">&emsp;PKR</option>

<option value="PLN,PLN">&emsp;PLN</option>

<option value="PYG,PYG">&emsp;PYG</option>

<option value="QAR,QAR">&emsp;QAR</option>

<option value="RON,RON">&emsp;RON</option>

<option value="RSD,RSD">&emsp;RSD</option>

<option value="RUB,RUB">&emsp;RUB</option>

<option value="RWF,RWF">&emsp;RWF</option>

<option value="SAR,SAR">&emsp;SAR</option>

<option value="SBD,SBD">&emsp;SBD</option>

<option value="SCR,SCR">&emsp;SCR</option>

<option value="SDG,SDG">&emsp;SDG</option>

<option value="SEK,SEK">&emsp;SEK</option>

<option value="SGD,SGD">&emsp;SGD</option>

<option value="SHP,SHP">&emsp;SHP</option>

<option value="SLL,SLL">&emsp;SLL</option>

<option value="SOS,SOS">&emsp;SOS</option>

<option value="SRD,SRD">&emsp;SRD</option>

<option value="STD,STD">&emsp;STD</option>

<option value="SVC,SVC">&emsp;SVC</option>

<option value="SYP,SYP">&emsp;SYP</option>

<option value="SZL,SZL">&emsp;SZL</option>

<option value="THB,THB">&emsp;THB</option>

<option value="TJS,TJS">&emsp;TJS</option>

<option value="TMT,TMT">&emsp;TMT</option>

<option value="TND,TND">&emsp;TND</option>

<option value="TOP,TOP">&emsp;TOP</option>

<option value="TRY,TRY">&emsp;TRY</option>

<option value="TTD,TTD">&emsp;TTD</option>

<option value="TWD,TWD">&emsp;TWD</option>

<option value="TZS,TZS">&emsp;TZS</option>

<option value="UAH,UAH">&emsp;UAH</option>

<option value="UGX,UGX">&emsp;UGX</option>

<option value="USD,USD">&emsp;USD</option>

<option value="UYU,UYU">&emsp;UYU</option>

<option value="UZS,UZS">&emsp;UZS</option>

<option value="VEF,VEF">&emsp;VEF</option>

<option value="VND,VND">&emsp;VND</option>

<option value="VUV,VUV">&emsp;VUV</option>

<option value="WST,WST">&emsp;WST</option>

<option value="XAF,XAF">&emsp;XAF</option>

<option value="XAG,XAG">&emsp;XAG</option>

<option value="XCD,XCD">&emsp;XCD</option>

<option value="XDR,XDR">&emsp;XDR</option>

<option value="XOF,XOF">&emsp;XOF</option>

<option value="XPF,XPF">&emsp;XPF</option>

<option value="YER,YER">&emsp;YER</option>

<option value="ZAR,ZAR">&emsp;ZAR</option>

<option value="ZMK,ZMK">&emsp;ZMK</option>

<option value="ZMW,ZMW">&emsp;ZMW</option>

<option value="ZWL,ZWL">&emsp;ZWL</option>
